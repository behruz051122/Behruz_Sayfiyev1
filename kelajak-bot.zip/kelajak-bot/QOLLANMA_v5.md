# v5.0 — YAKUNIY: Test tizimi, video tuzatishlari, tezkor navigatsiya

## Nima qo'shildi / tuzatildi

1. **To'liq test tizimi** — vaqtli, ketma-ket savollar, rasmli savol imkoniyati, natija va qayta ishlash
2. **Video "cho'zilib ketish" (resize) muammosi** — endi video sichqoncha bilan tortib o'lchamini o'zgartirib bo'lmaydi
3. **Tezkor navigatsiya** — video ostida endi **"☰ Barcha darslar ro'yxati"** tugmasi bor, bitta bosishda bo'lim ichidagi barcha darslarga qaytasiz
4. **Koinlar birlashtirildi** — video ko'rish va test yechishdan olingan koinlar bitta umumiy hisobda, **Natijalar** reytingida birgalikda ko'rinadi

---

## Joylashtiriladigan fayllar (5 ta)

- `database.py`
- `server.py`
- `webapp/index.html`
- `webapp/app.js`
- `webapp/style.css`

**Tegmang:** `config.py`, `bot.py`

Avvalgidek: fayllarni ko'chiring, git orqali yuboring:
```
git add .
git commit -m "v5.0 - test tizimi, video tuzatishlar"
git push
```
90 soniya kutib, botni qayta ishga tushiring.

---

## Test qanday yaratiladi (admin panel)

**1.** ⚙️ → pastga tushing → **"Testlar"** bo'limi → **"+ Yangi test"**

**2.** Formani to'ldiring:
   - **Fan:** Kimyo yoki Biologiya
   - **Test nomi:** masalan "Atom tuzilishi bo'yicha test"
   - **Murakkablik darajasi:** Oson (5 daqiqa) / O'rta (10 daqiqa) / Qiyin (15 daqiqa) — vaqt avtomatik shunga qarab belgilanadi, yoki qo'lda ham kiritishingiz mumkin

**3.** **"Testni saqlash"**

**4.** Test ro'yxatida paydo bo'lgach, **"Savollar"** tugmasini bosing

**5.** Har bir savol uchun:
   - **Savol matni**
   - **Rasm havolasi** (ixtiyoriy — agar savolga rasm kerak bo'lsa, uni biror joyga yuklab, havolasini shu yerga qo'ying)
   - **1-4 variantlar** — agar Rost/Yolg'on turidagi savol bo'lsa, faqat 1 va 2-variantlarni to'ldiring ("Rost", "Yolg'on"), 3-4 ni bo'sh qoldiring
   - **To'g'ri javob** — qaysi variant to'g'ri ekanini tanlang

**6.** **"Savolni saqlash"** — xohlagancha savol qo'shishingiz mumkin

---

## Test qanday ishlaydi (o'quvchi tomonidan)

1. Pastdagi **"Testlar"** bo'limiga o'tadi, fan bo'yicha filtrlaydi
2. Testni tanlab, **"Testni boshlash"** bosadi
3. Vaqt sanog'i boshlanadi, savollar birma-bir chiqadi
4. Har bir javob tanlangach, **avtomatik** keyingi savolga o'tadi
5. Vaqt tugasa (yoki barcha savollarga javob berilsa), natija chiqadi: necha to'g'ri, foiz
6. **"Qayta ishlash"** yoki **"Keyingi test"** tugmalari bilan davom etadi

**Muhim:** har bir savolga **birinchi marta** to'g'ri javob berilganda 1 coin beriladi. Qayta ishlaganda (retake) coin qayta berilmaydi — bu suiiste'molning oldini oladi, lekin mashq qilish cheklovsiz.

---

## Keyingi bosqichlar (agar davom ettirmoqchi bo'lsangiz)

- Payme/Click avtomatik to'lov integratsiyasi
- Profil bo'limida til tanlash va interfeys mavzulari
- Bildirishnomalar sozlamasi

Admin panel pastida endi **"v5.0"** yozuvi chiqishi kerak — shu orqali yangilanish joylashganini tasdiqlaysiz.
